<?php
	$pgsettings = array(
		"title" => "Edit / Sellers",
		"icon" => "icon-newspaper"
	);
	require_once("../../includes/begin_html.php");
?>

<?php include '../../includes/end_html.php'; ?>
